// TRANZO works in demo mode immediately. For real multi-user data, add Supabase credentials here.
window.TRANZO_CONFIG = {
  supabaseUrl: '',
  supabaseAnonKey: ''
};
