-- TRANZO production database schema for Supabase
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null default 'Користувач',
  phone text,
  avatar_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.listings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  category text not null check (category in ('car','moto','truck','special')),
  brand text not null,
  model text not null,
  year int not null check (year between 1886 and 2100),
  price numeric(14,2) not null check (price >= 0),
  currency text not null default 'USD',
  mileage int not null default 0 check (mileage >= 0),
  fuel text,
  transmission text,
  drive text,
  engine text,
  city text not null,
  description text,
  status text not null default 'active' check (status in ('active','sold','archived','moderation')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.listing_images (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.listings(id) on delete cascade,
  image_url text not null,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.favorites (
  user_id uuid not null references auth.users(id) on delete cascade,
  listing_id uuid not null references public.listings(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, listing_id)
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  listing_id uuid not null references public.listings(id) on delete cascade,
  reason text not null,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.listings enable row level security;
alter table public.listing_images enable row level security;
alter table public.favorites enable row level security;
alter table public.reports enable row level security;

create policy "public profiles read" on public.profiles for select using (true);
create policy "own profile insert" on public.profiles for insert with check (auth.uid() = id);
create policy "own profile update" on public.profiles for update using (auth.uid() = id);

create policy "active listings public read" on public.listings for select using (status = 'active' or auth.uid() = user_id);
create policy "own listing insert" on public.listings for insert with check (auth.uid() = user_id);
create policy "own listing update" on public.listings for update using (auth.uid() = user_id);
create policy "own listing delete" on public.listings for delete using (auth.uid() = user_id);

create policy "listing images public read" on public.listing_images for select using (true);
create policy "own listing images insert" on public.listing_images for insert with check (exists (select 1 from public.listings l where l.id = listing_id and l.user_id = auth.uid()));
create policy "own listing images delete" on public.listing_images for delete using (exists (select 1 from public.listings l where l.id = listing_id and l.user_id = auth.uid()));

create policy "own favorites read" on public.favorites for select using (auth.uid() = user_id);
create policy "own favorites insert" on public.favorites for insert with check (auth.uid() = user_id);
create policy "own favorites delete" on public.favorites for delete using (auth.uid() = user_id);

create policy "own reports insert" on public.reports for insert with check (auth.uid() = user_id);

create index if not exists listings_search_idx on public.listings(category, brand, model, city, price, year, created_at desc);
